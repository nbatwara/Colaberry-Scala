package KafkaMain

/**
  * Created by nehba_000 on 4/28/2017.
  */
object FileNumberTopic {
val Topic = "FileNumberTopic"
}
